/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.iesvdc.acceso.excelapi.excelapi;

/**
 *
 * @author matinal
 */
public class ExcelApiException extends Exception {

    public ExcelApiException(String msg) {
        super("ExcelApiException::" + msg);
    }
    
}
