package com.iesvdc.acceso.excelapi.excelapi;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *  Clase que nos permitirá crear una Hoja de Excel para posteriormente usarla en la clase Libro.
 * @author Óscar Caparrós
 */
public class Hoja {

    private String[][] datos;
    private String nombre;
    private int nFilas;
    private int nColumnas;
    
    /**
     * Crea una hoja de cálculo nueva.
     */
    public Hoja() {
        this.datos = new String[5][5];
        this.nombre = "";
        this.nFilas = 5;
        this.nColumnas = 5;
    }
    /**
     * Crea una hoja de cálculo nueva a partir de unos parámetros definidos por el usuario.
     * @param nFilas Número de filas de una hoja.
     * @param nColumnas Número de columnas de una hoja. 
     * @param nombre Nombre de la hoja.
     */
    public Hoja(int nFilas, int nColumnas, String nombre) {
        this.nFilas = nFilas;
        this.nColumnas = nColumnas;
        this.datos = new String[nFilas][nColumnas];
        this.nombre = nombre;
    }
    /**
     * Obtiene los datos de una celda de la hoja a partir de unos parámetros definidos por el usuario.
     * @param fila Número de la fila de una hoja.
     * @param columna Número de la columna de una hoja.
     * @return Cadena de carácteres con la información de la celda.
     */
    public String getDatos(int fila, int columna) throws ExcelApiException {
        if(fila > this.nFilas || columna > this.nColumnas)
            if(fila <= 0 || columna <= 0)
                throw new ExcelApiException("Hoja::getDatos(): Error con el número de fila y columna.");
        return this.datos[fila][columna];
    }
    /**
     * Define los datos de una celda de la hoja a partir de unos parámetros definidos por el usuario.
     * @param dato Datos a insertar en la celda.
     * @param fila Número de la fila.
     * @param columna Número de la columna.
     */
    public void setDatos(String dato, int fila, int columna) throws ExcelApiException {                
        if(fila > this.nFilas || columna > this.nColumnas)
            if(fila <= 0 || columna <= 0)
                throw new ExcelApiException("Hoja::setDatos(): Error con el número de fila y columna.");        
        this.datos[fila][columna] = dato;
    }
    /**
     * Obtiene el nombre de la hoja.
     * @return Nombre de la hoja.
     */
    public String getNombre() {
        return this.nombre;
    }
    /**
     * Define el nombre de una hoja.
     * @param nombre Nombre de la hoja.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }   
    /**
     * Obtiene el número de las filas.
     * @return Número de filas.
     */
    public int getnFilas() {
        return nFilas;
    }
    /**
     * Obtiene el número de columnas.
     * @return Número de columnas.
     */
    public int getnColumnas() {
        return nColumnas;
    }
    /**
     * Compara dos hojas para saber si son iguales.
     * @param hoja Hoja a comparar.
     * @return Booleano para saber el resultado.
     */
    public boolean compare(Hoja hoja) throws ExcelApiException{
        boolean success = true;
        
        if(this.nColumnas == hoja.getnColumnas() && this.nFilas == hoja.nFilas){
            for(int i = 0; i<this.nFilas ; i++){
                for(int j = 0; i<this.nColumnas ; j++){
                    try {
                        //System.out.println(this.getnColumnas() + "······································" + hoja.getnColumnas());
                        if(!this.getDatos(i,j).equals(hoja.getDatos(i,j))){
                            success = false;
                            break;
                        }
                    } catch (ExcelApiException ex) {
                        throw new ExcelApiException("Hoja::compare(): Error a la hora de comprar dos hojas.");
                    }
                }              
                if(!success) break;
            }
        }else{
            success = false;
        }
        
        return success;
    }
}
