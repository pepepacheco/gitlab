/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.iesvdc.acceso.excelapi.excelapi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Esta clase almacena informacion de libros para generar ficheros de excel.
 * Un libro de excel está compuesto por hojas
 * @author Óscar Caparrós
 * @version 1.0
 */
public class Libro {
    private List<Hoja> hojas;
    private String nombreArchivo;

    /**
     * Constructor por defecto de la clase Libro. Crea una lista de hoja por defecto y define el nombre del archivo como 'nuevo.xlsx'
     */
    public Libro() {
        this.hojas = new ArrayList<>();
        this.nombreArchivo = "nuevo.xlsx";
    }    
    /**
     * Constructor de la clase Libro cuyo parámetro define el nombre del archivo. También se crea una lista por defecto.
     * @param nombreArchivo Nombre del archivo a guardar/leer.
     */
    public Libro(String nombreArchivo) {
        this.hojas = new ArrayList<>();
        this.nombreArchivo = nombreArchivo;
    }    
    /**
     * Constructor de la clase Libro que inicializa las lista de hojas y el nombre del archivo.
     * @param hojas Lista de hojas del Libro.
     * @param nombreArchivo Nombre del archivo a guardar/leer.
     */
    public Libro(List<Hoja> hojas, String nombreArchivo) {
        this.hojas = hojas;
        this.nombreArchivo = nombreArchivo;
    }
    /**
     * Getter que devuelve las lista de hojas del Libro.
     * @return Lista de hojas
     */
    public List<Hoja> getHojas() {
        return hojas;
    }
    /**
     * Setter que inicializa la lista de hojas.
     * @param hojas Lista de hojas.
     */
    public void setHojas(List<Hoja> hojas) {
        this.hojas = hojas;
    }
    /**
     * Getter que devuelve el nombre del archivo.
     * @return Nombre del archivo.
     */
    public String getNombreArchivo() {
        return nombreArchivo;
    }
    /**
     * Setter que inicializa el nombre del archivo.
     * @param nombreArchivo Nombre del archivo.
     */
    public void setNombreArchivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }
    /**
     * Método que añade una hoja a la lista de hojas y devuelve un booleano para saber si se ha añadido satisfactoriamente
     * @param hoja Hoja a añadir en la lista.
     * @return Booleano para saber si se ha añadido la hoja correctamente.
     */
    public boolean addHoja(Hoja hoja){
        return this.hojas.add(hoja);
    }
    /**
     * Método que borra una hoja de la lista de hojas y devuelve si ha sido exitoso o no.
     * @param index Parámetro que define la posicion en la lista de la hoja a eliminar.
     * @return Booleano que devuelve si ha sido exitosa o no la eliminacion de la hoja.
     * @throws ExcelApiException Excepcion que es lanzada si la posicion de la hoja no es válida.
     */
    public Hoja removeHoja(int index) throws ExcelApiException{
        if(index < 0 || index > this.hojas.size())
           throw new ExcelApiException("Libro::removeHoja(): Posicion no válida");
        return this.hojas.remove(index);
    }
    /**
     * Método para obtener una hoja dependiendo de una posición.
     * @param index Posicion de la hoja a obtener de la lista
     * @return Hoja a obtener de la lista segun la posicion
     * @throws ExcelApiException Excepcion que es lanzada si la posicion de la hoja no es válida.
     */
    public Hoja indexHoja(int index) throws ExcelApiException{
        if(index < 0 || index > this.hojas.size())
           throw new ExcelApiException("Libro::indexHoja(): Posicion no válida");
        return this.hojas.get(index);
    }   
    /**
     * Método que lee el fichero.
     */
    public void load() throws ExcelApiException{
        
        HSSFWorkbook libro = new HSSFWorkbook();
        FileInputStream inputStream = null;
        
        try {  
            inputStream = new FileInputStream(new File(nombreArchivo));
            libro = new HSSFWorkbook(inputStream);
            Sheet primeraHoja = libro.getSheetAt(0);
            Iterator<Row> iterador = primeraHoja.iterator();

            while (iterador.hasNext()) {
                Row siguienteFila = iterador.next();
                Iterator<Cell> cellIterator = siguienteFila.cellIterator();

                while (cellIterator.hasNext()) {
                    Cell celda = cellIterator.next();

                    switch (celda.getCellType()) {
                        case Cell.CELL_TYPE_STRING:
                            System.out.print(celda.getStringCellValue());
                            break;
                        case Cell.CELL_TYPE_BOOLEAN:
                            System.out.print(celda.getBooleanCellValue());
                            break;
                        case Cell.CELL_TYPE_NUMERIC:
                            System.out.print(celda.getNumericCellValue());
                            break;
                    }
                    System.out.print(" -- ");
                }
                System.out.println();
            }             
        } catch (FileNotFoundException ex) {
            throw new ExcelApiException("Libro()::load(): Nombre del fichero no válido.");
        } catch (IOException ex) {
            throw new ExcelApiException("Libro()::load(): Error en la lectura del fichero.");
        } finally {
            try {
                inputStream.close();
                libro.close();
            } catch (IOException ex) {
                throw new ExcelApiException("Libro()::load(): Error a la hora de cerrar el flujo.");
            }
        }
           
    }
    /**
     * Método que lee el fichero mediante un nombre de fichero previamente definido como parámetro.
     * @param filename Nombre del fichero a leer.
     */
    public void load(String filename) throws ExcelApiException{
        this.nombreArchivo = filename;
        this.load();
    }
    /**
     * Método que guarda el libro en un fichero.
     * @throws ExcelApiException Excepcion que es lanzada si hay algún error a la hora de escribir el fichero.
     */
    public void save() throws ExcelApiException{
        
        SXSSFWorkbook wb = new SXSSFWorkbook();        
        //List<Hoja> listaHojas = new ArrayList<Hoja>();
        //Libro libro = new Libro(listaHojas, "nombreLibro.xlsx");
        //for each Hoja hija > this.hojas
        for (Hoja hoja : this.hojas) {
            Sheet sh = wb.createSheet(hoja.getNombre());
            for (int i = 0; i < hoja.getnFilas(); i++) {
                Row row = sh.createRow(i);
                for (int j = 0; j < hoja.getnColumnas(); j++) {
                    Cell cell = row.createCell(j);
                    cell.setCellValue(hoja.getDatos(i, j));//hoja.getDato(i,j)                
                }
        }   
        }
        
        try {
            FileOutputStream out = new FileOutputStream(this.nombreArchivo);
            wb.write(out);
            out.close();                         
        } catch (IOException ex) {
            throw new ExcelApiException("Error al guardar el archivo");
        } finally {
            wb.dispose();
        }
         
    }
    /**
     * Método que guarda un libro dependiendo de su nombre de archivo.
     * @param filename Nombre de archivo a guardar.
     * @throws ExcelApiException Excepcion que es lanzada si existe algún problema a la hora de guardar.
     */
    public void save(String filename)throws ExcelApiException{
        this.nombreArchivo = filename;
        this.save();
        
    }
    
    private void testExtension() throws ExcelApiException{
        //.xlsx
        if(nombreArchivo.length() >= 5){
            String extension = nombreArchivo.substring(nombreArchivo.length() - 5);
            if(!extension.equals(".xlsx")){
              nombreArchivo = nombreArchivo + ".xlsx";
            }                
        }else{
            throw new ExcelApiException("Longitud del nombre inválida");
        }
    }    
}