/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.iesvdc.acceso.excelapi.excelapi;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author matinal
 */
public class LibroTest {
    
    public LibroTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getHojas method, of class Libro.
     */
    @Test
    public void testGetHojas() {
        System.out.println("getHojas");
        Libro instance = new Libro();
        List<Hoja> lista = new ArrayList<Hoja>();
        instance.setHojas(lista);
        List<Hoja> expResult = instance.getHojas();
        List<Hoja> result = instance.getHojas();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setHojas method, of class Libro.
     */
    @Test
    public void testSetHojas() {
        System.out.println("setHojas");
        List<Hoja> hojas = null;
        Libro instance = new Libro();
        instance.setHojas(hojas);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getNombreArchivo method, of class Libro.
     */
    @Test
    public void testGetNombreArchivo() {
        System.out.println("getNombreArchivo");
        Libro instance = new Libro();
        String expResult = "nuevo.xlsx";
        String result = instance.getNombreArchivo();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setNombreArchivo method, of class Libro.
     */
    @Test
    public void testSetNombreArchivo() {
        System.out.println("setNombreArchivo");
        String nombreArchivo = "unNombre.xlsx";
        Libro instance = new Libro();
        instance.setNombreArchivo(nombreArchivo);
        assertEquals(nombreArchivo, instance.getNombreArchivo());
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of addHoja method, of class Libro.
     */
    @Test
    public void testAddHoja() throws ExcelApiException {
        System.out.println("addHoja");
        int filas = 20, columnas = 20;
        Hoja hoja = new Hoja(filas, columnas, "pepe");
        
        for(int i=0; i<filas; i++){
            for(int j=0; j<columnas; j++){
                try {
                    hoja.setDatos((char)('A'+j)+" "+(i+1), i, j);
                } catch (ExcelApiException ex) {
                    throw new ExcelApiException("LibroTest()::testAddHoja(): Error al intentar insertar datos en la hoja.");
                }
            }
        }        
        Libro instance = new Libro();
        instance.addHoja(hoja);
        try {
            assertEquals(instance.indexHoja(0).compare(hoja), true);
        } catch (ExcelApiException ex){
            fail("No puede acceder a la hoja");
        }
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of removeHoja method, of class Libro.
     */
    @Test
    public void testRemoveHoja() throws Exception {
        System.out.println("removeHoja");
        int index = 0;
        Libro instance = new Libro();
        Hoja expResult = new Hoja(5, 5, "hoja");
        for(int i=0; i<5; i++){
            for(int j=0; j<5; j++){
                expResult.setDatos((char)('A'+j)+" "+(i+1), i, j);
            }
        }        
        instance.addHoja(expResult);
        Hoja result = instance.removeHoja(index);
        //System.out.println(result.getNombre() + "--------------------------------------------" + expResult.getNombre());
        assertEquals("Error en removeHoja():", result.compare(expResult), true);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /*
     * Test of indexHoja method, of class Libro.
     *
    @Test
    public void testIndexHoja() throws Exception {
        System.out.println("indexHoja");
        int index = 0;
        Libro instance = new Libro();
        Hoja expResult = null;
        Hoja result = instance.indexHoja(index);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    */

    /**
     * Test of load method, of class Libro.
     */
    @Test
    public void testLoad_0args() throws ExcelApiException {
        System.out.println("Leyendo libro...");
        Libro instance = new Libro("nombreArchivo.xlsx");
        instance.save();
        try {
            instance.load();
        } catch (ExcelApiException ex) {
            throw new ExcelApiException("LibroTest::testLoad_0args(): Error al intentar hacer el load().");
        }
        // TODO review the generated test code and remove the default call to fail.
        //assertEquals("", true, instance.compare(instance.load()));
        fail("The test case is a prototype.");
    }

    /**
     * Test of load method, of class Libro.
     */
    @Test
    public void testLoad_String() throws ExcelApiException {
        System.out.println("load");
        String filename = "ejemplo.xlsx";
        Libro instance = new Libro();
        instance.save(filename);
        try {
            instance.load(filename);
        } catch (ExcelApiException ex) {
            throw new ExcelApiException("LibroTest::testLoad_String(): Error al intentar cargar un libro.");
        }
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of save method, of class Libro.
     */
    @Test
    public void testSave_0args() throws Exception {
        System.out.println("save");
        Libro instance = new Libro("test.xlsx");
        Hoja hoja1 = new Hoja(6, 6, "hoja1");
        Hoja hoja2 = new Hoja(10, 10, "hoja2");    
        for(int i=0; i<6; i++){
            for(int j=0; j<6; j++){
                hoja1.setDatos((char)('A'+j)+" "+(i+1), 6, 6);
            }
        }        
        for(int i=0; i<10; i++){
            for(int j=0; j<10; j++){
                hoja2.setDatos((char)('A'+j)+" "+(i+1), 10, 10);
            }
        }        
        instance.addHoja(hoja1);
        instance.addHoja(hoja2);
        instance.save();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }    
}
