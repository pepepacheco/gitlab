﻿# APIExcel

Descripción
==================


Este proyecto trata de completar una sencilla API para importar/exportar a Excel, que sea capaz de volcar matrices de texto a hojas en libros de Excel.S