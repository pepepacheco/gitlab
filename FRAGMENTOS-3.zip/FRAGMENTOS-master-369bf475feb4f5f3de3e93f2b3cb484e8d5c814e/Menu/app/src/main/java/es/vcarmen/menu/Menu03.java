package es.vcarmen.menu;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class Menu03 extends AppCompatActivity {

    public static final int MNU_OPC1 = 1;

    private static final int MNU_OPC2 = 2;

    private static final int MNU_OPC3 = 3;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu03);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu03, menu);
        return true;
    }
}
