package es.vcarmen.fragmento9;

import android.support.v4.app.FragmentPagerAdapter;

/**
 * Created by matinal on 26/10/17.
 */

public class Adaptor extends FragmentPagerAdapter {
}
