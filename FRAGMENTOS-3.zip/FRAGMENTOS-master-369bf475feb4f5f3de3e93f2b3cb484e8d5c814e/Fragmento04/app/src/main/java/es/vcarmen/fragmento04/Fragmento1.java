package es.vcarmen.fragmento04;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;

/**
 * Created by matinal on 11/10/17.
 */

public class Fragmento1 extends DialogFragment {

    static Fragmento1 nuevaInstancia(String titulo){
        Fragmento1 fragmento = new Fragmento1();
        Bundle args = new Bundle();
        args.putString("titulo", titulo);
        fragmento.setArguments(args);
        return fragmento;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        String titulo = getArguments().getString("titulo");
        return new AlertDialog.Builder(getActivity()).
                setTitle(titulo). //Añadimos imagen
                setIcon(R.mipmap.ic_launcher). //Añadimos Positivo
                setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ((Fragmento04)getActivity()).positivo();
                    }}). //Añadimos Negativo
                setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ((Fragmento04)getActivity()).negativo();
                    }}). //Añadimos neutral
                setNeutralButton("Neutro", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ((Fragmento04)getActivity()).neutro();
                    }}).
                    create();
        }
}
