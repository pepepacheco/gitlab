package com.iesvirgendelcarmen.javi.dam.fragmentosjava;

import android.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

/* Ejercicios de fragmento 2 */






public class MainActivity extends AppCompatActivity {

    final Fragmento1 fragmento1 = new Fragmento1();
    final Fragmento2 fragmento2 = new Fragmento2();
    private  boolean cambio = false;
    final FragmentTransaction FT = getSupportFragmentManager().beginTransaction();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        /*Ahora manejare la acción del botón el controlador de eventos.
        Button boton = (Button) findViewById(R.id.boton1);
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cambio){
                    FT.replace(R.id.contenedor1, fragmento1);
                }else {
                    FT.replace(R.id.contenedor1, fragmento2);
                }

                FT.addToBackStack(null);
                FT.commit();

                cambio = !cambio;
            }
        });
        */


        WindowManager windowManager = getWindowManager();
        Display display = windowManager.getDefaultDisplay();

        if(display.getRotation() == Surface.ROTATION_90 || display.getRotation() == Surface.ROTATION_270){
            FT.replace(R.id.contenedor1, fragmento1).commit();
        } else if ((display.getRotation() == Surface.ROTATION_0 || display.getRotation() == Surface.ROTATION_180)) {
            FT.replace(R.id.contenedor1, fragmento2).commit();
        }
        //FT.replace(R.id.contenedor1, fragmento2);
    }


    //Este era el primer boton que mostraba el primer fragmento


   /* public void boton1(View view){
        Fragmento1 fragmento = new Fragmento1();
        FragmentManager FM = getSupportFragmentManager();
        FragmentTransaction FT = FM.beginTransaction();
        FT.add(R.id.contenedor1, fragmento);
        FT.commit();
    } */

    // Este era el segundo boton que mostraba el segundo fragmento.
/*
    public void boton2(View view){
        Fragmento2 fragmento = new Fragmento2();
        FragmentManager FM = getSupportFragmentManager();
        FragmentTransaction FT = FM.beginTransaction();
        FT.add(R.id.contenedor1, fragmento);
        FT.commit();
    }
        */
}
