package es.vcarmen.fragment07;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by matinal on 19/10/17.
 */

public class Fragmento2 extends Fragment {

    private Button btn2;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragmento2, container,false);
    }

    @Override
    public void onStart() {
        super.onStart();


        Button btn1 = (Button) getActivity().findViewById(R.id.importarTexto1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView lbl = (TextView) getActivity().findViewById(R.id.texto1);
                Toast.makeText(getActivity(), lbl.getText(), Toast.LENGTH_SHORT).show();
            }
        });

        Button btn2 = (Button)getActivity().findViewById(R.id.importarTexto2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView texto = (TextView)getActivity().findViewById(R.id.texto2);
                texto.setText("Tocado FRAG2");
            }
        });
    }
}
