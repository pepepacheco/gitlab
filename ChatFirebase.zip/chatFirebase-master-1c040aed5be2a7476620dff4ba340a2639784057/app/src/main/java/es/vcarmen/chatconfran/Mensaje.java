package es.vcarmen.chatconfran;

/**
 * Created by matinal on 7/11/17.
 */

public class Mensaje {
    private String msg;

    public Mensaje(){

    }

    public Mensaje(String msg) {
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
