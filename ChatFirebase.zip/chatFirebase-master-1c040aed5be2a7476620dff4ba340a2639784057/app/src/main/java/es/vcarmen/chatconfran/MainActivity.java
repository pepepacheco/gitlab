package es.vcarmen.chatconfran;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.w3c.dom.Text;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {

    Mensaje msg;

    @BindView(R.id.tvMensaje)
    TextView mensaje;

    @BindView(R.id.btnEnviar)
    Button enviar;

    @BindView(R.id.etEntrada)
    EditText entrada;

    FirebaseDatabase database;
    DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        conectarFirebase();
        leerFirebase();
    }

    private void conectarFirebase() {
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("chat");

    }

    public void leerFirebase(){
        myRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                if (dataSnapshot != null && dataSnapshot.getValue() != null){
                    msg = dataSnapshot.getValue(Mensaje.class);
                    insertarMensaje(msg);
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public void insertarMensaje(Mensaje arg){
        if(msg.getMsg() != null){
            mensaje.append("\n");
            mensaje.append(msg.getMsg());
        }
    }

    @OnClick(R.id.btnEnviar)
    public void enviarMensaje(){
        String cadena = entrada.getText().toString();
        limpiarEntrada();
        Mensaje msg = new Mensaje(cadena);
        guardarMensaje(msg);
    }

    private void guardarMensaje(Mensaje msg) {
        myRef.push().setValue(msg);
    }

    private void limpiarEntrada() {
        entrada.setText("");
    }
}
