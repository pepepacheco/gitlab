/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.iesvdc.acceso.dao;

import com.iesvdc.acceso.controlador.CrearAlumno;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author matinal
 */
public class Conexion {

    private Properties propiedades = new Properties();
    private Integer driver;
    private String host;
    private String port;
    private String database_name;
    private String username;
    private String password;
    
    public static final int ORACLE = 1;
    public static final int MYSQL = 2;
    public static final int DERBY = 3;
    public static final int POSTGRE = 4;
    
    public String jdbcUrl = "";
    
    public Conexion() throws DAOException{
        try (InputStream in = new FileInputStream(new File("db.prop")); ) {           
            propiedades.load(in);                                    
        } catch (IOException ex) {
            throw new DAOException("Conexion: error a la hora de leer el fichero de propiedades.");
        }
        loadProperties();
    }
    
    public Connection getConnection() throws DAOException{
        Connection conexion = null;        
        switch(driver){
            case ORACLE:
                jdbcUrl = "jdbc:oracle:thin:@" + this.host + ":" + this.port  + ":" + this.database_name;
                break;
            case MYSQL:
                jdbcUrl = "jdbc:oracle:thin:@" + this.host + ":" + this.port  + ":" + this.database_name;
                break;
            case DERBY:
                jdbcUrl = "jdbc:derby://" + this.host + ":" + this.port  + "/" + this.database_name;
                break;
            case POSTGRE:
                jdbcUrl = "jdbc:oracle:thin:@" + this.host + ":" + this.port  + ":" + this.database_name;
                break;
            default:
                throw new DAOException("Conexion: el driver seleccionado no está disponible"); 
        }
        try {
            conexion = DriverManager.getConnection(jdbcUrl);
        } catch (SQLException ex) {
            throw new DAOException("Conexion:getConnection(): Error a la hora de obtener la conexión.");
        }
        return conexion;
    }
    
    public Conexion(int driver) throws DAOException{
        switch(driver){
            case ORACLE:
                break;
            case MYSQL:
                break;
            case DERBY:
                break;
            case POSTGRE:
                break;
            default:
                throw new DAOException("Conexion: el driver seleccionado no está disponible");
        }
    }
    
    private void loadProperties(){
        this.database_name = this.propiedades.getProperty("base_datos");
        this.driver = Integer.parseInt(propiedades.getProperty("driver"));
        this.host = this.propiedades.getProperty("host");
        this.password = this.propiedades.getProperty("password");
        this.port = this.propiedades.getProperty("puerto");
        this.username = this.propiedades.getProperty("username");
        
        String path = CrearAlumno.obtenerPath();
    }
    
}
