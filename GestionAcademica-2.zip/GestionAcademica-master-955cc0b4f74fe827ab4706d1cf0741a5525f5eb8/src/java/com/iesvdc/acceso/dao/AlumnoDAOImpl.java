/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.iesvdc.acceso.dao;

import com.iesvdc.acceso.pojo.Alumno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author matinal
 */
public class AlumnoDAOImpl implements AlumnoDAO{
    
    Conexion conex;
    Connection con = null;
    String sql;
    
    private Conexion obtenerConexion() throws DAOException{
        if(conex == null){
            conex = new Conexion();            
        }         
        return conex;
    }
    
    public AlumnoDAOImpl(){}

    @Override
    public void create(Alumno alumno) throws DAOException{
        try {
            con = obtenerConexion().getConnection();
            sql = "INSERT INTO ALUMNO VALUES(NULL, ?, ?);";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, alumno.getNombre());
            pstm.setString(2, alumno.getApellido());
            pstm.execute();
            
            con.close();
        } catch (SQLException ex) {
            throw new DAOException("AlumnoDAOImpl: No puede conectar a la BBDD.");
        }
    }

    @Override
    public void update(Alumno old_al, Alumno new_al) throws DAOException {
        try {
            con = obtenerConexion().getConnection();
            sql = "UPDATE ALUMNO SET(id=?, nombre=?, apellido=?) WHERE (id=?);";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setInt(1, new_al.getId());
            pstm.setString(2, new_al.getNombre());
            pstm.setString(3, new_al.getApellido());
            pstm.setString(4, old_al.getNombre());
            pstm.execute();
            
            con.close();
        } catch (SQLException ex) {
            throw new DAOException("AlumnoDAOImpl: No puede conectar a la BBDD.");
        }
    }

    @Override
    public void update(Integer old_id, Alumno new_al) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Integer id) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Alumno alumno) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Alumno findById(Integer id) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Alumno> findByNombre(String Nombre) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Alumno> findByApellido(String Apellido) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
