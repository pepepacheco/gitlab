package com.iesvirgendelcarmen.actividadestema1;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Actividad15 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad15);
        inicialize();
    }

    private void inicialize(){
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linearLayout);

        Animation animation = AnimationUtils.loadAnimation(this, R.anim.rotacion);
        animation.setRepeatMode(1);
        animation.setRepeatCount(20);

        TextView texto = new TextView(this);
        texto.setText("TEXTO GIRANDO");
        texto.setPadding(0,300,0,0);
        texto.setTextSize(24f);
        texto.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        texto.setTextColor(Color.argb(255,255,0,0));
        texto.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));

        texto.setAnimation(animation);

        linearLayout.addView(texto);
    }
}
