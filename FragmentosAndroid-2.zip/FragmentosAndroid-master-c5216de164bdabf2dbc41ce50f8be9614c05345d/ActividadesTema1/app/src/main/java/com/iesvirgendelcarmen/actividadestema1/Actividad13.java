package com.iesvirgendelcarmen.actividadestema1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Actividad13 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad13);
        inicialize();
    }

    private void inicialize(){
        TextView texto = (TextView) findViewById(R.id.textoTranslacion);
        texto.append("\nTEXTO MOVIENDOSE");

        Animation animation = AnimationUtils.loadAnimation(this, R.anim.translacion);
        animation.setRepeatCount(Animation.INFINITE);
        animation.setRepeatMode(Animation.INFINITE);

        texto.setAnimation(animation);
    }
}
