package com.iesvirgendelcarmen.actividadestema1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Actividad07 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad07);
        inicialize();
    }

    private void inicialize(){
        TextView texto = (TextView) findViewById(R.id.texto);
        texto.setText("TEXTO DESDE JAVA");
        texto.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

    }
}
