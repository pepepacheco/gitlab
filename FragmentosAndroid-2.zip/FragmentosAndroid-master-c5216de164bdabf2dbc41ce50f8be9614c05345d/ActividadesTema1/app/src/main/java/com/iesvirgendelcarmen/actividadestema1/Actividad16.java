package com.iesvirgendelcarmen.actividadestema1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Actividad16 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad16);
        inicialize();
    }

    private void inicialize(){
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.ampliacion);
        TextView texto = (TextView) findViewById(R.id.textviewAmpliacion);
        texto.setAnimation(animation);
    }
}
