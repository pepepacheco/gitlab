package com.iesvirgendelcarmen.actividadestema1;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Actividad14 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad14);
        inicialize();
    }

    private void inicialize(){
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linearLayout);

        Animation animation = AnimationUtils.loadAnimation(this, R.anim.movimiento);
        animation.setRepeatMode(1);
        animation.setRepeatCount(20);
        animation.setFillBefore(true);

        TextView texto = new TextView(this);
        texto.setText("OVERSHOOT");
        texto.setPadding(0,300,0,0);
        texto.setTextSize(24f);
        texto.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        texto.setTextColor(Color.argb(255,0,0,255));
        texto.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));

        texto.setAnimation(animation);
        texto.append("\nRepeat mode: 1");
        texto.append("\nRepeat count: 20");


        linearLayout.addView(texto);
    }
}
