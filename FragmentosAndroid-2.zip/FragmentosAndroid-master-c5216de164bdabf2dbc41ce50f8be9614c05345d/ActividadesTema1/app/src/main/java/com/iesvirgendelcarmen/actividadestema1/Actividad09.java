package com.iesvirgendelcarmen.actividadestema1;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Actividad09 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad09);
        inicialize();
    }

    private void inicialize(){
        TextView texto = (TextView) findViewById(R.id.texto);
        texto.setText("NUEVO TEXTO");
        texto.setTextColor(Color.argb(100,255,0,0));
    }
}
