package es.vcarmen.material11;

import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class material11 extends AppCompatActivity {

    NavigationView navigationView;
    DrawerLayout drawerLayout;
    String titulo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_material11);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        navigationView = findViewById(R.id.navigator);
        drawerLayout = findViewById(R.id.drawer);

        if (savedInstanceState == null){
            respuesta(titulo);
        }

        titulo = getResources().getString(R.string.menu1_1);

        final ActionBar abar = getSupportActionBar();

        if(abar != null){
            abar.setHomeAsUpIndicator(R.drawable.menu);
            abar.setDisplayHomeAsUpEnabled(true);
        }

        if(navigationView != null){configuraDrawer(navigationView);}
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if(!drawerLayout.isDrawerOpen(GravityCompat.START)) {
            getMenuInflater().inflate(R.menu.main, menu);
            return true;
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.opcion1:
                Toast.makeText(getApplication(), "TOCADA OPCION1", Toast.LENGTH_SHORT).show();
                break;
            case android.R.id.home:
                drawerLayout.openDrawer(GravityCompat.START);
                break;
            default:
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private void configuraDrawer(NavigationView navigationView){
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                item.setChecked(true);

                String title = item.getTitle().toString();
                respuesta(title);

                return false;
            }
        });
    }

    private void respuesta(String title){
        //Snackbar.make(getCurrentFocus(), title, Snackbar.LENGTH_SHORT).show();
        Bundle args = new Bundle();
        args.putString(Fragmentos.ARG_SECTION_TITLE, title);
        Fragmentos fragmento = Fragmentos.newInstance(title);
        fragmento.setArguments(args);
        getSupportFragmentManager().beginTransaction().replace(R.id.contenido, fragmento).commit();
        drawerLayout.closeDrawers();
        setTitle(title);
    }
}
