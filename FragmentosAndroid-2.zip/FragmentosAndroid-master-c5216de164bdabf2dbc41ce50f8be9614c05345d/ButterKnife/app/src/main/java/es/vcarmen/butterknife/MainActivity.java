package es.vcarmen.butterknife;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TabHost;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
 */

public class MainActivity extends AppCompatActivity {

    @BindView(android.R.id.tabhost) TabHost tabHost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        //ButterKnife.bind(this);
        //titulo.setText("Texto cambiado con ButterKnife");
        tabHost.setup();

        TabHost.TabSpec spec;
        spec = tabHost.newTabSpec("tab1");
        spec.setIndicator("Pestaña 1");
        spec.setContent(R.id.Tab1);
        tabHost.addTab(spec);

        TabHost.TabSpec spec2;
        spec2 = tabHost.newTabSpec("tab2");
        spec2.setIndicator("Pestaña 2");
        spec2.setContent(R.id.Tab2);
        tabHost.addTab(spec2);

        tabHost.setCurrentTab(0);
        tabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String s) {

            }
        });

    }
    /**
    @OnClick(R.id.Tab1)
    public void cambiarNombre() {
        titulo.setText("Se ha hecho click.");
    }
    */
}
