package es.vcarmen.constraintlayout;

import android.content.Intent;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.QuickContactBadge;

public class MainActivity extends AppCompatActivity {

    private int i = 0;
    private ProgressBar bar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button boton = (Button) findViewById(R.id.button2);
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                accionSnackbar();
            }
                /**bar = (ProgressBar) findViewById(R.id.progressBar2);


                if(i == 0 || i == 10){
                    bar.setVisibility(View.VISIBLE);
                    bar.setMax(150);
                }else if(i < bar.getMax()){
                    bar.setProgress(i);
                }else{
                    bar.setProgress(0);
                    i = 0;
                    bar.setVisibility(View.GONE);
                }
                i = i + 10;
            }
                 */
        });
    }

    private void accionSnackbar(){
        Snackbar snackbar = Snackbar.make(findViewById(R.id.layout), "¿LLAMAR A: 123456789?", Snackbar.LENGTH_LONG);
        snackbar.setAction("ACEPTAR", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel:123456789"));
                startActivity(callIntent);
            }
        });
        snackbar.show();
        /**
        Intent callIntent = new Intent(Intent.ACTION_DIAL);
        callIntent.setData(Uri.parse("tel:123456789"));
        startActivity(callIntent);
         */
    }
}
