package es.vcarmen.chatapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.textViewMensajes) TextView historial;
    @BindView(R.id.botonEnviar) Button botonEnviar;
    @BindView(R.id.entrada) EditText entrada;
    FirebaseDatabase database;
    DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        //Seria mejor crear una clase o una interfaz para la conexion.
        conectarFirebase();
        actualizarHistorialMensajes();
    }

    @OnClick(R.id.botonEnviar)
    public void enviarMensaje(){
        Mensaje msg = new Mensaje(entrada.getText().toString());
        limpiarEntrada();
        guardarMensaje(msg);
    }

    public void limpiarEntrada(){
        entrada.setText("");
    }

    public void conectarFirebase(){
        //Conexion a la base de datos
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("chat");
    }

    public void guardarMensaje(Mensaje mensaje){
        myRef.push().setValue(mensaje);
    }

    private void actualizarHistorialMensajes(){
        myRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                if(dataSnapshot != null && dataSnapshot.getValue() != null){
                    Mensaje msg = dataSnapshot.getValue(Mensaje.class);
                    insertarMensaje(msg);
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void insertarMensaje(Mensaje msg){
        if(msg.getMensaje() != null)
            historial.append("\n" + msg.getMensaje());
    }
}
