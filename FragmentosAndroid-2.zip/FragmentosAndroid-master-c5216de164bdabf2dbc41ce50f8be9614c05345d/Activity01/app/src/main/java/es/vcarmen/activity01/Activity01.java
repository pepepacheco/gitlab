package es.vcarmen.activity01;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Activity01 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_01);
    }

    public void boton(View view){
        Intent i = new Intent(Activity01.this, Activity02.class);
        startActivity(i);
    }

    @Override
    public void onPause() {
        super.onPause();
        finish();
    }
}
