package es.vcarmen.exameniu2017;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.Date;
import java.util.List;

/**
 * Óscar Caparrós Tortosa 2ºDAM
 */
public class ListaProductoActivity extends AppCompatActivity {

    private ListView listaGrafica;
    private List<Producto> listaProductos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_producto);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);

        initialize();
    }

    private void initialize(){
        listaGrafica = findViewById(R.id.listaProductos);
        listaProductos = Catalogo.listaProductos;

        if(listaProductos.isEmpty()) {
            listaProductos.add(new Producto(String.valueOf(R.mipmap.icono2), "Titulo", "5€", "Categoria1", "Descricion", new Date()));
            listaProductos.add(new Producto(String.valueOf(R.mipmap.icono1), "Titulo2", "15€", "Categoria2", "Descricion2", new Date()));
        }

        ListaAdapter adaptador = new ListaAdapter(this, R.layout.item_lista, listaProductos);
        listaGrafica.setAdapter(adaptador);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.activityAddProducto:
                Intent i = new Intent(this, FormProductoActivity.class);
                startActivity(i);
                finish();
                return true;
            case R.id.activityLista:
                Intent in = new Intent(this, ListaProductoActivity.class);
                startActivity(in);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
