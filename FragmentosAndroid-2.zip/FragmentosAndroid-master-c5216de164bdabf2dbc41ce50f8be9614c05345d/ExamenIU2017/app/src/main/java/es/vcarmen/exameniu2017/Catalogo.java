package es.vcarmen.exameniu2017;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by matinal on 12/12/2017.
 */

public class Catalogo {
    public static List<Producto> listaProductos = new ArrayList<>();

    public static void addProducto(Producto producto){
        listaProductos.add(producto);
    }

    public static List<Producto> getLista(){
        return listaProductos;
    }
}
