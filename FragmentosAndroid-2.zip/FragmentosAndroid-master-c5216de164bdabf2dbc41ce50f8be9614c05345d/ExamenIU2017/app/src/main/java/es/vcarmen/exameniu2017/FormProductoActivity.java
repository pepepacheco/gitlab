package es.vcarmen.exameniu2017;

import android.content.Intent;
import android.database.DataSetObserver;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

/**
 * Óscar Caparrós Tortosa 2ºDAM
 */
public class FormProductoActivity extends AppCompatActivity {

    private EditText titulo;
    private EditText precio;
    private EditText descripcion;
    private Spinner foto;
    private Spinner categoria;
    private Button botonVender;

    private String tituloProducto;
    private String precioProducto;
    private String descripcionProducto;
    private String fotoProducto;
    private String categoriaProducto;
    private Date fechaVenta = new Date();

    private Producto producto;

    private final static String[] coleccionCategorias = { "Motor", "Electrónica", "Deporte", "Libros" };
    private final static String[] coleccionFotos = { "Moto", "Coche" };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_producto);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);

        initialize();
    }

    private void initialize(){
        titulo = findViewById(R.id.etTituloProducto);
        precio = findViewById(R.id.etPrecioProducto);
        descripcion = findViewById(R.id.etDescripcionProducto);
        foto = findViewById(R.id.etFotoProducto);
        accionSpinnerFoto();
        categoria = findViewById(R.id.etCategoriaProducto);
        accionSpinnerCategoria();
        botonVender = findViewById(R.id.botonVender);


        botonVender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obtenerDatosProducto();
                addProductoToLista(producto);

                startActivity(new Intent(getApplicationContext(), ListaProductoActivity.class));
                finish();
            }
        });
    }

    private void obtenerDatosProducto(){
        tituloProducto = titulo.getText().toString();
        precioProducto = precio.getText().toString();
        descripcionProducto = descripcion.getText().toString();
        fotoProducto = foto.getSelectedItem().toString();
        accionFotoElegida();
        categoriaProducto = categoria.getSelectedItem().toString();

        if(precioProducto.charAt(precioProducto.length() - 1) != '€')
            precioProducto = precioProducto + "€";

        producto = new Producto(fotoProducto, tituloProducto, precioProducto, categoriaProducto, descripcionProducto, fechaVenta);
    }

    private void addProductoToLista(Producto producto){
        Catalogo.addProducto(producto);
        Log.v("Correcto", "Contenido lista: " + Catalogo.getLista().get(0).toString());
    }

    private void accionSpinnerFoto(){
        ArrayAdapter adaptador = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, coleccionFotos);
        foto.setAdapter(adaptador);
    }

    private void accionSpinnerCategoria(){
        ArrayAdapter adaptador = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, coleccionCategorias);
        categoria.setAdapter(adaptador);
    }

    private void accionFotoElegida(){
        switch (fotoProducto){
            case "Moto":
                fotoProducto = String.valueOf(R.mipmap.icono1);
                break;
            case "Coche":
                fotoProducto = String.valueOf(R.mipmap.icono2);
                break;
            default:
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.activityAddProducto:
                Intent i = new Intent(this, FormProductoActivity.class);
                startActivity(i);
                finish();
                return true;
            case R.id.activityLista:
                Intent in = new Intent(this, ListaProductoActivity.class);
                startActivity(in);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
