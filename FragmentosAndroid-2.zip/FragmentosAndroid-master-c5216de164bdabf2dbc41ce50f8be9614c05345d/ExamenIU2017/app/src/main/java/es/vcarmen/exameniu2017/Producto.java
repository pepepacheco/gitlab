package es.vcarmen.exameniu2017;

import java.util.Date;

/**
 * Created by matinal on 12/12/2017.
 */

public class Producto {
    private String foto;
    private String titulo;
    private String precio;
    private String categoria;
    private String descripcion;
    private Date fecha;

    public Producto(String foto, String titulo, String precio, String categoria, String descripcion, Date fecha) {
        this.foto = foto;
        this.titulo = titulo;
        this.precio = precio;
        this.categoria = categoria;
        this.descripcion = descripcion;
        this.fecha = fecha;
    }

    public String getFoto() {
        return foto;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getPrecio() {
        return precio;
    }

    public String getCategoria() {
        return categoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Date getFecha() {
        return fecha;
    }

    @Override
    public String toString() {
        return "Producto{" +
                "foto='" + foto + '\'' +
                ", titulo='" + titulo + '\'' +
                ", precio='" + precio + '\'' +
                ", categoria='" + categoria + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", fecha=" + fecha +
                '}';
    }
}
