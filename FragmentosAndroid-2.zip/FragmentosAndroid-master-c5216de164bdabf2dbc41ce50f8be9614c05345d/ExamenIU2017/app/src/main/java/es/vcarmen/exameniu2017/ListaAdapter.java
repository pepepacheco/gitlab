package es.vcarmen.exameniu2017;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by matinal on 12/12/2017.
 */

public class ListaAdapter extends ArrayAdapter {
    public ListaAdapter(Context context, int resource) {
        super(context, resource);
    }

    public ListaAdapter(Context context, int resource, List objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;

        if(view == null){
            LayoutInflater vi = LayoutInflater.from(getContext());
            view = vi.inflate(R.layout.item_lista, null);
        }

        Producto p = (Producto) getItem(position);

        if(p != null){
            ImageView imagen = view.findViewById(R.id.imagenProducto);
            TextView titulo = view.findViewById(R.id.tituloProducto);
            TextView precio = view.findViewById(R.id.precioProducto);
            TextView categoria = view.findViewById(R.id.categoriaProducto);
            TextView fecha = view.findViewById(R.id.fechaProducto);

            imagen.setImageResource(Integer.parseInt(p.getFoto()));
            titulo.setText(p.getTitulo());
            precio.setText(p.getPrecio());
            categoria.setText(p.getCategoria());
            fecha.setText(String.valueOf(p.getFecha()));
        }


        return view;
    }
}
