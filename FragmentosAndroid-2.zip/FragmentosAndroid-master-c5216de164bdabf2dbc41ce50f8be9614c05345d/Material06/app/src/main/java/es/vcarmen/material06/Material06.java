package es.vcarmen.material06;

import android.graphics.Color;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Material06 extends AppCompatActivity {

    private TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_material06);
        initialize();
    }

    private void initialize(){
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        //tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        //tabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);
        tabLayout.setTabTextColors(Color.RED, Color.argb(50,50,50,50));
        tabLayout.setSelectedTabIndicatorColor(Color.GREEN);
        tabLayout.setSelectedTabIndicatorHeight(12);

        TabLayout.Tab primerTab = tabLayout.newTab();
        primerTab.setText("TAB 01");
        primerTab.setIcon(R.mipmap.ic_launcher);

        TabLayout.Tab segundoTab = tabLayout.newTab();
        segundoTab.setText("TAB 02");
        segundoTab.setIcon(R.drawable.icono1);

        TabLayout.Tab tercerTab = tabLayout.newTab();
        tercerTab.setText("TAB 03");
        tercerTab.setIcon(R.drawable.ic_action_name);

        tabLayout.addTab(primerTab);
        tabLayout.addTab(segundoTab);
        tabLayout.addTab(tercerTab,1,true);

        Button botonAdd = (Button) findViewById(R.id.botonAdd);
        botonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                crearNuevaTab();
            }
        });

        Button botonDel = (Button) findViewById(R.id.botonQuitar);
        botonDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                eliminarTab();
            }
        });

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int elegida = tabLayout.getSelectedTabPosition();
                switch (elegida){
                    case 0:
                        Toast.makeText(getApplicationContext(), "PRIMERA TAB", Toast.LENGTH_SHORT).show();
                        break;
                    case 1:
                        Toast.makeText(getApplicationContext(), "SEGUNDA TAB", Toast.LENGTH_SHORT).show();
                        break;
                    case 2:
                        Toast.makeText(getApplicationContext(), "TERCERA TAB", Toast.LENGTH_SHORT).show();
                        break;
                    default:
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    private void crearNuevaTab(){
        if(tabLayout.getTabCount() < 6){
            TabLayout.Tab nuevaTab = tabLayout.newTab();
            nuevaTab.setText("TAB 0" + tabLayout.getTabCount());

            tabLayout.addTab(nuevaTab);
        }else{
            Toast.makeText(getApplicationContext(), "MÁXIMO DE TABS ALCANZADO", Toast.LENGTH_SHORT).show();
        }
    }

    private void eliminarTab(){
        if(tabLayout.getTabCount() > 0){
            tabLayout.removeTab(tabLayout.getTabAt(tabLayout.getTabCount()-1));
        }else{
            Toast.makeText(getApplicationContext(), "NO PUEDES ELIMINAR MÁS TABS", Toast.LENGTH_SHORT).show();
        }
    }
}
