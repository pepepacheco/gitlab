package es.vcarmen.gridlayout;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by matinal on 30/10/2017.
 */

public class ContactoAdapter extends BaseAdapter {

    private List<Contacto> lista;
    private Context mContext;

    public ContactoAdapter(Context mContext, List<Contacto> lista) {
        this.mContext = mContext;
        this.lista = lista;
    }

    @Override
    public int getCount() {
        return lista.size();
    }

    @Override
    public Object getItem(int i) {
        return lista.get(i);
    }

    @Override
    public long getItemId(int i) {
        return lista.get(i).hashCode();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        Contacto c = (Contacto) getItem(i);

        if(view  == null){
            view = LayoutInflater.from(mContext).inflate(R.layout.gridview_contacto, viewGroup, false);
        }

        ImageView image = view.findViewById(R.id.foto);
        TextView nombre = view.findViewById(R.id.nombre);
        TextView apellidos = view.findViewById(R.id.apellidos);

        nombre.setText(c.getNombre());
        apellidos.setText(c.getApellidos());
        image.setImageResource(c.getFoto());

        return view;
    }
}
