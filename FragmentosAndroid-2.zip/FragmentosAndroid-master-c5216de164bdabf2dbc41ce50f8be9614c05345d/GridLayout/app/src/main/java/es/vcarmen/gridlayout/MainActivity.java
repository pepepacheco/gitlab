package es.vcarmen.gridlayout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Contacto> agenda;
    private ContactoAdapter adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        agenda = new ArrayList<Contacto>();
        mockAgenda();
        GridView miGridView = (GridView) findViewById(R.id.gridView);
        adaptador = new ContactoAdapter(this, agenda);
        miGridView.setAdapter(adaptador);
    }

    public void mockAgenda(){
        Contacto c;

        c = new Contacto("Osqui","Chusqui",R.drawable.foto1);
        agenda.add(c);

        c = new Contacto("Jose","Amargada",R.drawable.foto2);
        agenda.add(c);

        c = new Contacto("Jose","Amargada",R.drawable.foto2);
        agenda.add(c);

        c = new Contacto("Jose","Amargada",R.drawable.foto2);
        agenda.add(c);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_opciones, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int idSeleccionado = item.getItemId();
        switch (idSeleccionado){
            case R.id.opcion1:
                Toast.makeText(getApplicationContext(), "Seleccionada opcion1", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.opcion2:
                Toast.makeText(getApplicationContext(), "Seleccionada opcion2", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.opcion3:
                Toast.makeText(getApplicationContext(), "Seleccionada opcion3", Toast.LENGTH_SHORT).show();
                return true;
            default:
                super.onOptionsItemSelected(item);
        }
        return true;
    }

}
