package es.vcarmen.fragment06;

import android.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Fragment06 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment06);
        inicialize();
    }

    private void inicialize(){
        Button boton = (Button) findViewById(R.id.boton);
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction FT = getFragmentManager().beginTransaction();
                Fragmento1 fragmento1 = new Fragmento1();

                FT.add(R.id.contenedor, fragmento1);
                FT.commit();
            }
        });
    }
}
