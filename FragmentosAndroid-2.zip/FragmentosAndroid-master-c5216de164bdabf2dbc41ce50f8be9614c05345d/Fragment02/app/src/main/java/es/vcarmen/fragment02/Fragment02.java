package es.vcarmen.fragment02;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class Fragment02 extends AppCompatActivity {

    private boolean cambio = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment02);

        final Fragmento1 f1 = new Fragmento1();
        final Fragmento2 f2 = new Fragmento2();
        final Fragmento3 f3 = new Fragmento3();
        final Fragmento4 f4 = new Fragmento4();

        FragmentManager FM = getSupportFragmentManager();
        FragmentTransaction FT = FM.beginTransaction();

        WindowManager WM = getWindowManager();
        Display DP = WM.getDefaultDisplay();

        FT.add(R.id.contenedor, f1);

        if(DP.getRotation() == Surface.ROTATION_0)
            FT.replace(R.id.contenedor, f1);
        if(DP.getRotation() == Surface.ROTATION_90)
            FT.replace(R.id.contenedor, f2);
        if(DP.getRotation() == Surface.ROTATION_180)
            FT.replace(R.id.contenedor, f3);
        if(DP.getRotation() == Surface.ROTATION_270)
            FT.replace(R.id.contenedor, f4);

        FT.commit();
    }


}
