package com.iesvirgendelcarmen.dam.socialtech;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //Atributos del layout

    private TextView tvNombre;
    private TextView tvApellido;
    private TextView tvTelefono;
    private TextView tvEmail;

    private EditText etNombre;
    private EditText etApellido;
    private EditText etTelefono;
    private EditText etEmail;

    private TextView tvFormacion;
    private Spinner spFormacion;

    private SeekBar sbEdad;
    private TextView tvEdad;

    private ListView list;

    //Clase Contacto

    private Contacto contacto;
    private ArrayList<Contacto> listaContactos = new ArrayList<Contacto>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Obtenemos la informacion del bundle y lo guardamos en la lista
        if(savedInstanceState != null)
            listaContactos = (ArrayList<Contacto>) savedInstanceState.getSerializable("listaContactos");

        //ID de los componentes de layout

        etNombre = (EditText) findViewById(R.id.etNombre);
        etApellido = (EditText) findViewById(R.id.etApellido);
        etTelefono = (EditText) findViewById(R.id.etTelefono);
        etEmail = (EditText) findViewById(R.id.etEmail);

        sbEdad = (SeekBar) findViewById(R.id.seekBar);
        tvEdad = (TextView) findViewById(R.id.textSeekBar);

        sbEdad.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvEdad.setText(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        rellenarInformacionSpinner();

        //ListView
        list = (ListView) findViewById(R.id.listaContactos);
        AdapterContacto adaptador = new AdapterContacto(this, listaContactos);
        list.setAdapter(adaptador);
    }

    private void rellenarInformacionSpinner(){
        String[] listaFormaciones = {"SMR","DAM","DAW","ASIR","Ingenieria tecnica informatica",
                "Ingenieria Informatica","Grado","Otros"};

        spFormacion = (Spinner) findViewById(R.id.spFormacion);
        spFormacion.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listaFormaciones));
    }

    //Metodo que guarda la informacion en un objeto contacto
    public void guardarContacto(View view){
        String nombre = etNombre.getText().toString();
        String apellido = etApellido.getText().toString();
        String telefono = etTelefono.getText().toString();
        String email = etEmail.getText().toString();

        contacto = new Contacto(nombre, apellido, telefono, email);
        //Log.v("Contacto 1 ", contacto.toString());
        listaContactos.add(contacto);
        //Log.v("Contacto 1 en lista ", listaContactos.get(0).toString());
    }

    //Método que guarda la lista en el bundle para poder recuperarla al girar la pantalla
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("listaContactos", listaContactos);
    }

}
