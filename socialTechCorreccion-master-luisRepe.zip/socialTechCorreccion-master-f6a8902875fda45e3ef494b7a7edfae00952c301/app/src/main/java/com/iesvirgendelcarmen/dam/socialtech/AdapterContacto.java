package com.iesvirgendelcarmen.dam.socialtech;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by profesor on 25/10/17.
 */

public class AdapterContacto extends ArrayAdapter<Contacto>{
    public AdapterContacto(Context context, ArrayList<Contacto> users) {
        super(context, 0, users);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Contacto aux = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.vista_contacto, parent, false);
        }

        TextView nombre = (TextView) convertView.findViewById(R.id.listNombre);
        TextView email = (TextView) convertView.findViewById(R.id.listEmail);

        nombre.setText(aux.getNombre()+" "+aux.getApellido());
        email.setText(aux.getEmail());

        return convertView;
    }
}
