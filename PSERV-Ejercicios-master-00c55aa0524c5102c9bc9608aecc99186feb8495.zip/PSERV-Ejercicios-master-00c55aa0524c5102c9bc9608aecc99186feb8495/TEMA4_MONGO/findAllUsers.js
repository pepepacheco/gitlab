var User = require('./users.js').User;

User.find({first_name: /^M/, id: {$gt:800}}, function(err, data) {
    if(err) throw err;
    console.log(data);
});