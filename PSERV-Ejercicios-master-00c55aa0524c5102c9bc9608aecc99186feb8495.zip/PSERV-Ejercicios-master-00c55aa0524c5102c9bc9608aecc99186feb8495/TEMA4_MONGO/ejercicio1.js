var User = require('./users.js').User;

function userClousure() { 
    return {
        createUserIdEq : function(_id, _sex, _age, _name) {
            var newUser = new User({
                id   : _id,
                sex  : _sex,
                age  : _age,
                name : _name
            });
            
            newUser.save(function(err) {
                if(err) throw err;
                console.log("Usuario " + newUser.name + " creado correctamente.");
            });
        },
        
        findUserAgeEq : function(age) {
            User.find({edad: {$eq: 100}}, function(err, data) {
                if(err) throw err;
                console.log(data);
            })
        },
        
        findUserAgeBetween : function(lAge, gAge) {
            User.find({edad: {$gt: 98, $lt: 100}}, function(err, data) {
                if(err) throw err;
                console.log(data);
            })  
        },
        
        findUserVocalEq : function(age) {
            User.find({name: /^AEIOU/}, function(err, data) {
                
            })
        }
    };
};

var a = userClousure();

a.findUserAgeBetween(98, 100);