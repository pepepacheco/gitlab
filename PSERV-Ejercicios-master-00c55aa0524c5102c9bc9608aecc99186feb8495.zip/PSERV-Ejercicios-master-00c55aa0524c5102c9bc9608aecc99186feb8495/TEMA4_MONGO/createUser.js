var User = require('./users.js').User;
var db   = require('./users.js').db;

var newUser = User({
    id        : 1010,
    firstName : 'Joaquín',
    lastName  : 'Pérez',
    email     : 'joaquinp@gmail.com'
});

newUser.save(function(err) {
    if(err) throw err;
    console.log('Usuario con id ' + newUser.id + ' creado correctamente.');
});