var mongoose = require('mongoose');

var db     = mongoose.connect('mongodb://localhost/ejercicio');
var Schema = mongoose.Schema;

var userSchema = new Schema({
    id   : Number,
    sex  : String,
    age  : Number,
    name : String
});

var User = mongoose.model('Personas', userSchema);

module.exports.User = User;
module.exports.db   = db;