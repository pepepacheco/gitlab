var User = require('./users.js').User;

User.findOneAndRemove({first_name: /^M/}, function(err) {
    if(err) throw err;
    console.log('Usuario borrado.');
});