var User = require('./users.js').User;

//findOneAndUpdate({busqueda}, {cambio}, [...])
User.findOneAndUpdate({firstName:'Joaquín'}, {first_name:'Antonio'}, function(err, data) {
    if(err) throw err;
    console.log('Usuario modificado correctamente. Resultados: ');
    console.log(data);
});