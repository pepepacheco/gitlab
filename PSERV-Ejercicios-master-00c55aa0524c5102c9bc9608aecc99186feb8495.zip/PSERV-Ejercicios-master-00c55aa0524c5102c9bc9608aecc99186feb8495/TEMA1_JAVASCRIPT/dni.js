// Comprobamos si el usuario ha puesto argumentos

if(process.argv.length < 3) {
    console.log("No hay argumentos");
    process.exit(1);
}

console.log("Documento leido: " + process.argv[2]);
const cadena = process.argv[2];

// Creamos un clousure para crear objetos documento

var documento = function(cadena) {
    var _documento = cadena;
    var calcularLetra = function() {
        const letras = "TRWAGMYFPDXBNJZSQVHLCKET";
        var numero = parseInt(_documento, 10);
        console.log(letras.);
        return letras[numero];
    }
    
    return {
        comprobarFormato : function() {return /^[\d]{8}[a-zA-Z]?$/.test(_documento)},
        comprobarDNIoNIF : function() {if(this.comprobarFormato()) {
                                          if(_documento.length == 8) {
                                                return 'NIF';
                            
                                          } else {
                                              return 'DNI';
                                          }
                                      } else {
                                          return "Formato incorrecto.";
                                      }},
        
        generarLetraDNI : function() {if(this.comprobarDNIoNIF() == 'DNI') {
                                         return calcularLetra();
                                         
                                     } else if(this.comprobarDNIoNIF() == 'NIF') {
                                         return 'Es un NIF'; 
                                     } else {
                                         return "Documento NO válido.";
                                     }},
    }
};

// Hay que crear un objeto para acceder a los métodos
var d = documento(cadena);

console.log("¿Formato correcto? " + d.comprobarFormato());
console.log("¿DNI o NIF? " + d.comprobarDNIoNIF());
console.log("¿Letra DNI? " + d.generarLetraDNI());