function suma(sumando1, sumando2) {
    setTimeout(function() {
        return sumando1 + sumando2;
    }, 500);
}

var resultado = suma(5,2);
console.log(resultado);