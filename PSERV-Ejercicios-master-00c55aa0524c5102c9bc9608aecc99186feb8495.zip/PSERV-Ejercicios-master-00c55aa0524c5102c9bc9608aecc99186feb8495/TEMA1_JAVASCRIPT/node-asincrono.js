var fs = require('fs');

var data = fs.readFile('\ejemplo.txt', 'utf-8', function(err, data) {
    if(err) {
        console.log('Se ha producido un error. ' + err);
    } else {
        console.log(data);
    }
});

console.log('Fin del programa');