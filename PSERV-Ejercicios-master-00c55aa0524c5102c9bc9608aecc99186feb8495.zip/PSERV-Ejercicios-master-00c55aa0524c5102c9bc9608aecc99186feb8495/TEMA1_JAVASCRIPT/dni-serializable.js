// Comprobamos si el usuario ha puesto argumentos

if(process.argv.length < 3) {
    console.log("No hay argumentos");
    process.exit(1);
}

console.log("Documento leido: " + process.argv[2]);
const cadena = process.argv[2];

// Creamos un clousure para crear objetos documento

var documento = function(cadena) {
    var _documento = cadena;
    
    var calcularLetra = function() {
        const letras = "TRWAGMYFPDXBNJZSQVHLCKET";
        var numero = parseInt(_documento, 10);
        return letras[numero];
    }
    
    var comprobarFormato = function() {
        return /^[\d]{8}[a-zA-Z]?$/.test(_documento)
    };
        
    var comprobarDNIoNIF = function() {
        if(comprobarFormato()) {
          if(_documento.length == 8) {
                return 'NIF';

          } else {
              return 'DNI';
          }
         } else {
            return "Formato incorrecto.";
    }};
    
    var generarLetraDNI = function() {
        if(comprobarDNIoNIF() == 'DNI') {
             return calcularLetra();

         } else if(comprobarDNIoNIF() == 'NIF') {
             return 'Es un NIF'; 
         } else {
             return "Documento NO válido.";
         }
    };
    
    return {
        documentoSerializado : function() {
            var documento = {};
            
            documento.formato_correcto = comprobarFormato();
            documento.tipoDocumento    = comprobarDNIoNIF();
            documento.letra_dni        = generarLetraDNI();
            
            console.log(typeof documento);
            console.log(typeof JSON.stringify(documento));
            
            return JSON.stringify(documento);
        }
    }
    
}

// Hay que crear un objeto para acceder a los métodos
var d = documento(cadena);

console.log(d.documentoSerializado());

/*console.log("¿Formato correcto? " + d.comprobarFormato());
console.log("¿DNI o NIF? " + d.comprobarDNIoNIF());
console.log("¿Letra DNI? " + d.generarLetraDNI());*/