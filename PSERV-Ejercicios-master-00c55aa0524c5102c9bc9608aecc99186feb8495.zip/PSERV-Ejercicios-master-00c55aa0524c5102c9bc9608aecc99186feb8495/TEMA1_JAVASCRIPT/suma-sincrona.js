function suma(sumando1, sumando2) {
    return sumando1 + sumando2;
}

var resultado = suma(2,5);
console.log(resultado);