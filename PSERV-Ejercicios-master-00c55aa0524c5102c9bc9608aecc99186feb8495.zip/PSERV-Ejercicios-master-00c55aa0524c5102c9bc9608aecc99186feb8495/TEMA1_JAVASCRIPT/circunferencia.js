// Modulo para Node

function circunferencia(radio) {
    var _radio = radio;

    return {
        perimetro : function () {return 2 * Math.PI * _radio; },
        area      : function () {return Math.PI * Math.pow(radio, 2); }
    };
}

module.exports = circunferencia;
console.log("Hola");

function triangulo(base, altura) {
    var _base = base;
    var _altura = altura;

    return {
        area : function() {return base * altura},
    };
}

module.exports = triangulo;
