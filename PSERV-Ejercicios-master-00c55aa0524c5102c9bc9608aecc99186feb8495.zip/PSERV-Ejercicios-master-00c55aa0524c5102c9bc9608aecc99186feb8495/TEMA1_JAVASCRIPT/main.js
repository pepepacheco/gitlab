var circunferencia = require('./circunferencia');
var triangulo = require('./triangulo');

var objeto = circunferencia(12).area();
var objetoTriangulo = triangulo(2,3).area();

console.log(objeto);
console.log(objetoTriangulo);
