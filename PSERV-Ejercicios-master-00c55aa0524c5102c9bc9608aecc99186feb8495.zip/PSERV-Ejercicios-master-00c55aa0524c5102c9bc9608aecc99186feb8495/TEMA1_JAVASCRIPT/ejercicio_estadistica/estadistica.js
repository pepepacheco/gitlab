function estadistica(numbers, arg) {
    var _numbers = numbers;

    return {
        countNumbers : function() {return _numbers.length},

        getMaxValue  : function() {
            var maxValue = 0;

            _numbers.forEach(function(element) {
                if(element > maxValue)
                    maxValue = element;

            }, this);

            return maxValue;
        },

        getMinValue  : function() {
            var minValue = this.getMaxValue();

            _numbers.forEach(function(element) {
                if(element < minValue)
                    minValue = element;
            });

            return minValue;
        },

        getNumberOfRepetedNumber : function() {
            var counter = 0;
            
            _numbers.forEach(function(element) {
                if(element == arg)
                    counter++;
            });

            return counter;
        },

        sortNumbers  : function() {
            return _numbers.sort(function(a,b) {return a-b});
        },

        getAverageNumber : function() {
            var totalNumber = 0;
            _numbers.forEach(function(element) {
                totalNumber += element;
            });

            return totalNumber / _numbers.length;
        },
    }
}

module.exports = estadistica;