var estadistica = require('./estadistica');

var numeros = [-3,1,2,2,2,2,3,4,5,36,70,8,9];
var arg = process.argv[2];

var objeto = estadistica(numeros, arg);

console.log("El numero de números es: " + objeto.countNumbers());
console.log("El número de veces que se repite el número es: " + objeto.getNumberOfRepetedNumber());
console.log("El número medio es: " + objeto.getAverageNumber());
console.log("El valor máximo de la colección es: " + objeto.getMaxValue());
console.log("El valor mínimo de la colección es: " + objeto.getMinValue());
console.log("Colección ordenada: " + objeto.sortNumbers());


