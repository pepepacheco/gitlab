var name = "Jose";

function clousure() {
    var name = 'Manuel';
    function funcion() {
        return name;
    };
    
    return funcion();
}

console.log(clousure());