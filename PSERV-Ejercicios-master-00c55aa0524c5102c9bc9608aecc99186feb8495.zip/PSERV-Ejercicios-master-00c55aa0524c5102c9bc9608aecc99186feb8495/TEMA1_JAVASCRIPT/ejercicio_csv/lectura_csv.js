var fs = require('fs');
var coleccionPersonas = require('./persona');

var lectura = function lectura(path, callback) {
    var persona  = {};
    var personas = [];
    
    fs.readFile(path, 'utf-8', function(err, data) {
        if(err) throw err;
        
        var lineas = data.split('\r\n');
        for(var i = 1; i < lineas.length - 1; i++) {
            //console.log(lineas[i]);
            var trozo = lineas[i].split(',');
            
            persona = {
                nombre   : trozo[0],
                apellido : trozo[1],
                email    : trozo[2],
                sexo     : trozo[3],
                edad     : parseInt(trozo[4])
            };
    
            personas.push(persona);
        }
    
        callback(personas);

        // TEST
        console.log('PERSONAS MAS EDAD');
        var arrayPersonas = coleccionPersonas(personas);
        var coleccionPersonasMismoSexo = arrayPersonas.personasConEdadEnExtremos();
        console.log(coleccionPersonasMismoSexo);

    });
}

module.exports = lectura;