var coleccionPersonas = function(arrayPersonas) {
    var _arrayPersonas = arrayPersonas;
    return {
        personasIgualSexo         : function(sexo) {
            var array = [];
            for(var i = 0; i < _arrayPersonas.length; i++) {
                if(_arrayPersonas[i].sexo == sexo)
                    array.push(_arrayPersonas[i]);
            }

            return array;
        },

        personasConMasEdad        : function(edad) {
            var array = [];
            for(var i = 0; i < _arrayPersonas.length; i++) {
                if(_arrayPersonas[i].edad > edad)
                    array.push(_arrayPersonas[i]);
            }

            return array;
        },

        personasConEdadEnExtremos : function() {
            var extremos         = {};
            var masEdad          = _arrayPersonas[0].edad;
            var menorEdad        = _arrayPersonas[0].edad;

            for(var i = 1; i < _arrayPersonas.length; i++) {
                if(_arrayPersonas[i].edad > masEdad) {
                    masEdad = _arrayPersonas[i].edad;
                    extremos.personaMasEdad = _arrayPersonas[i];
                }

                if(_arrayPersonas[i].edad < menorEdad) {
                    menorEdad = arrayPersonas[i].edad;
                    extremos.personaMenorEdad = _arrayPersonas[i];
                }
            }

            return extremos;

        }
    }
}

module.exports = coleccionPersonas;