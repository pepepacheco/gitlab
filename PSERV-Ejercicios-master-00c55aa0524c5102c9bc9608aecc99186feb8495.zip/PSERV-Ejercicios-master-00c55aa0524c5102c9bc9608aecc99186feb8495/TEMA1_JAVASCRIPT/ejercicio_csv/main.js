var lectura = require('./lectura_csv');

lectura('datos.csv', function(datos) {
    
});