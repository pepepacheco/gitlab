function clousure() {
    var n = 0;
    
    return {
        count: function() {return n++},
        reset: function() {return n = 0}
    };
}

var c = clousure();

console.log(c.count());
console.log(c.count());
console.log(c.reset());
console.log(c.count());
