var fs = require('fs');

var data = fs.readFile('\ejemplo.txt');
console.log(data);
console.log('Fin del programa');