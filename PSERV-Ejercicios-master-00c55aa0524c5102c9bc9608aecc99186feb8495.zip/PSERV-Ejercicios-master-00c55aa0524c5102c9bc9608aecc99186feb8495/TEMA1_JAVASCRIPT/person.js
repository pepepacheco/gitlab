//ASIGNACION DE FUNCIONES A OBJETOS

var person = {
    name: "Nicholas",
    sayName: function() {
        console.log(person.name);
    }
};

person.sayName();

//PRUEBA DE VISIBILIDAD DE VARIABLES

var a = 1;

function foo() {
    var a = 2; // Aunque tengan el mismo nombre son dos variables diferentes
    console.log(a);
}

foo();
console.log(a);

// Encerrando funciones por seguridad

(function foo() {
    console.log("Esto es una función encerrada. Se ejecuta sin llamarla");
})();