package com.iesvirgendelcarmen.actividadestema1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Actividad11 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad11);
        imprimir("añadiendo texto con print");
        imprimir("añadiendo texto otra vez");
    }

    private void imprimir(String textoAImprimir){
        TextView texto = (TextView) findViewById(R.id.texto);
        texto.append(textoAImprimir+"\n");
    }
}
