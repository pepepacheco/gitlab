package com.iesvirgendelcarmen.actividadestema1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Actividad10 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad10);
        inicialize();
    }

    private void inicialize() {
        String texto = "NUEVO MÉTODO DE TEXTO";
        TextView idTexto = (TextView) findViewById(R.id.texto);
        idTexto.setText(texto);
    }
}
