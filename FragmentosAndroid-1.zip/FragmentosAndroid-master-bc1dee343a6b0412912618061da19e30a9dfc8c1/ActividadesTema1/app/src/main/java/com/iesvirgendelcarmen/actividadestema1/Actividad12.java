package com.iesvirgendelcarmen.actividadestema1;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Actividad12 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad12);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.layout1);
        primerTexto(linearLayout);
        segundoTexto(linearLayout);
    }

    private void primerTexto(LinearLayout linearLayout){
        TextView texto = new TextView(this);
        texto.setText("PRIMER TEXTO");
        texto.setTextColor(Color.argb(255,255,0,0));
        texto.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        linearLayout.addView(texto);
    }

    private void segundoTexto(LinearLayout linearLayout){
        TextView texto = new TextView(this);
        texto.setText("SEGUNDO TEXTO");
        texto.setTextSize(24f);
        texto.setTextColor(Color.argb(255,0,0,255));
        texto.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        linearLayout.addView(texto);
    }
}
