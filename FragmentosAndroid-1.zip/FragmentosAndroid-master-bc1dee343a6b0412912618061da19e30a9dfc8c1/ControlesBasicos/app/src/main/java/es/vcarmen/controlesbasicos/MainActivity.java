package es.vcarmen.controlesbasicos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    final String[] artistas = {"Oscar", "Jose", "Antonio", "Peter", "Angel"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inicialize();
    }

    public void inicialize(){
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, artistas);
        AutoCompleteTextView acTextView = (AutoCompleteTextView) findViewById(R.id.acTextView);
        acTextView.setAdapter(arrayAdapter);

        ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, artistas);
        MultiAutoCompleteTextView macTextView = (MultiAutoCompleteTextView) findViewById(R.id.macTextView);
        macTextView.setAdapter(arrayAdapter2);
        macTextView.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, artistas));
    }
}
