package es.vcarmen.fragment07;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by matinal on 19/10/2017.
 */

public class Fragmento2 extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragmento2, container, false);
    }

    @Override
    public void onStart() {
        super.onStart();
        Button btn1 = (Button)getActivity().findViewById(R.id.importarTexto2);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView lbl = (TextView)getActivity().findViewById(R.id.Texto1);
                Toast.makeText(getActivity(), lbl.getText(), Toast.LENGTH_SHORT).show();
            }
        });
        Button btn2 = (Button) getActivity().findViewById(R.id.exportarTexto2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView texto = (TextView)getActivity().findViewById(R.id.Texto2);
                texto.setText("TOCADO FRAG2");
            }
        });
    }
}
