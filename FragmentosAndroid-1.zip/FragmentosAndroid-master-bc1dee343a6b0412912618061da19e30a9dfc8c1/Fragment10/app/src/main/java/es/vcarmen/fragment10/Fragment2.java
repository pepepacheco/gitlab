package es.vcarmen.fragment10;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;

/**
 * Created by matinal on 26/10/2017.
 */

public class Fragment2 extends FragmentActivity {
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_unpanel);
        Toast.makeText(getBaseContext(), "estoy en el 2 ", Toast.LENGTH_SHORT).show();

        if(savedInstanceState == null){
            Bundle arguments = new Bundle();
            arguments.putString(Fragment3.ARG_ID_ENTRADA_SELECCIONADA, getIntent().getStringExtra(Fragment3.ARG_ID_ENTRADA_SELECCIONADA));

            Fragment3 fragment = new Fragment3();
            fragment.setArguments(arguments);

            getSupportFragmentManager().beginTransaction().add(R.id.frame_contenedor, fragment).commit();
        }

    }


}
