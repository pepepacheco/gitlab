package com.iesvirgendelcarmen.practica;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Created by matinal on 19/09/2017.
 */

public class ActivitySecundaria extends AppCompatActivity{

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secundaria);
        inicialize();
    }

    private void inicialize(){
        /**
        TextView refactor = (TextView) findViewById(R.id.textoActivityDos);
        refactor.setText(R.string.saludo_boton);*/

        final Context context = this.getApplicationContext();

        final ImageView image = (ImageView) findViewById(R.id.corazon);
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Animation anim = AnimationUtils.loadAnimation(context, R.anim.escala);
                anim.setRepeatCount(Animation.INFINITE);

                image.startAnimation(anim);

            }
        });

    }

}
