package com.iesvirgendelcarmen.practica;

import android.content.Context;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.graphics.Typeface;
import android.widget.TextView;

public class ActivityPrincipal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
        inicialize();
    }

    private void inicialize(){
        final Context context = this.getApplicationContext();
        Button boton = (Button) findViewById(R.id.boton);

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button boton = (Button) findViewById(R.id.boton);
                boton.setText(R.string.cambioTextoBoton);
                boton.setTextColor(ResourcesCompat.getColor(getResources(), R.color.colorAccent, getTheme()));

                animation(boton);
                changeFont(boton);
                /**
                Intent i = new Intent(ActivityPrincipal.this, ActivitySecundaria.class);
                startActivity(i);
                 */

            }
        });
    }

    private final void animation(Button boton){
        AnimationSet animationSet = new AnimationSet(true);

        AlphaAnimation alphaAnimation = new AlphaAnimation(0,1);
        alphaAnimation.setDuration(1500);

        int rs = RotateAnimation.RELATIVE_TO_SELF;
        RotateAnimation rotacion = new RotateAnimation(0,360,rs,0.5f,rs,0.5f);
        rotacion.setDuration(1000);

        animationSet.addAnimation(rotacion);
        animationSet.addAnimation(alphaAnimation);

        boton.startAnimation(animationSet);
    }

    private void changeFont(Button boton){
        Typeface fuente = Typeface.createFromAsset(getAssets(), "fonts/newFont.ttf");
        boton.setTypeface(fuente);

    }
}
