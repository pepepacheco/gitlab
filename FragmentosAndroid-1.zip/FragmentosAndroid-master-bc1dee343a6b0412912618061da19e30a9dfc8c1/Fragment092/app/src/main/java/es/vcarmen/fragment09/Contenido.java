package es.vcarmen.fragment09;

/**
 * Created by matinal on 25/10/2017.
 */

public class Contenido {
    public static final String[] pintores = { "RENOIR", "REMBRANT",  "GAUGUIN", "BOTICELLI", "RAFAEL","MASACCIO", "DELACROIX", "VELAZQUEZ" };
    public static final String[] escultores = { "MIGUEL ANGEL", "RODIN", "DONATELLO", "BERNINI", "BRANCUSI", "FIDIAS","CANOVA", "MOORE", "THORVALDSEN" };
    public static final String[] arquitectos = { "GAUDÍ", "BRUNELLESCHI", "BORROMINI", "VAN DER ROHE", "LE CORBUSIER", "NORMAN FOSTER",  "LLOYD WRIGHT", "VASARI"};
}
