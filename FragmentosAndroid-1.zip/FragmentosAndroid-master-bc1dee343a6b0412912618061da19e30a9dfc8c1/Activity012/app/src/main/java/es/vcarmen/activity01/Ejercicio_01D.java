package es.vcarmen.activity01;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Ejercicio_01D extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio_01_d);
    }

    public void boton1(View view){
        Intent i = new Intent(this, Ejercicio_01A.class);
        startActivity(i);
    }


    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}
