package es.vcarmen.fragment04;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Fragment04 extends AppCompatActivity {

    private Button botonDialogo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment04);
        inicialize();
    }

    private void inicialize(){
        botonDialogo = (Button) findViewById(R.id.botonDialogo);
        botonDialogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragmento1 fr = Fragmento1.nuevaInstancia("DIALOGO FRAGMENT");
                fr.show(getFragmentManager(), "dialogo");
            }
        });
    }

    public void doPositiveClick(){
        Toast.makeText(this, "OK PULSADO", Toast.LENGTH_SHORT).show();
    }

    public void doNegativeClick(){
        Toast.makeText(this, "CANCELAR PULSADO", Toast.LENGTH_SHORT).show();
    }

}
