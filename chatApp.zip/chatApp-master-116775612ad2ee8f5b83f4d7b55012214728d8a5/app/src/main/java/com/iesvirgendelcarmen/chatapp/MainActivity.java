package com.iesvirgendelcarmen.chatapp;

import android.os.Debug;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnEditorAction;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.entrada)
    EditText entrada;

    @BindView(R.id.mensajes)
    TextView mensajes;

    FirebaseDatabase database;
    DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("mensajes");

        myRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                if (dataSnapshot != null && dataSnapshot.getValue() != null) {
                    try {

                        Mensaje msg = dataSnapshot.getValue(Mensaje.class);
                        addMensaje(msg);
                    } catch (Exception ex) {
                        Log.e("Error", ex.getMessage());
                    }
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


    }

    @OnEditorAction(R.id.entrada)
    public boolean editor(int actionId) {
        Log.d("action", actionId+"");
        if (actionId == EditorInfo.IME_ACTION_SEND ) {
            Mensaje msg = new Mensaje(entrada.getText().toString());
            mandaMensaje(msg);
            //addMensaje(msg);
            limpiaMensaje();
            return true;
        }
        return false;
    }

    public void addMensaje(Mensaje msg) {
        if (msg!=null) {
            mensajes.append("\n- " + msg.getMensaje());
        }
    }

    public void limpiaMensaje() {
        entrada.setText("");
    }

    public void mandaMensaje(Mensaje msg) {
        myRef.push().setValue(msg);
    }


}
